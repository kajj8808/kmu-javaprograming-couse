
public class ColorPoint extends Point {
    private int x, y;
    private String colorName;

    public ColorPoint(int x, int y, String colorName) {
        /* super class에 argument가 있을때 super을 써줘야 아무 문제없이 사용가능. */
        super(x, y);
        this.colorName = colorName;
    }

    private void setColor(String colorName) {
        this.colorName = colorName;
    }

    private void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public String toString() {
        return this.colorName + "색의 (" + this.x + "," + this.y + ")의 점";
    }

    public static void main(String[] args) throws Exception {
        ColorPoint cp = new ColorPoint(5, 5, "yellow");
        cp.setXY(10, 20);
        cp.setColor("RED");
        String str = cp.toString();
        System.out.println(str + "입니다.");

    }
}
